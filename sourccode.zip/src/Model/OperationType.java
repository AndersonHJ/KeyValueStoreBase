package Model;

/**
 * Operation type
 * @author Shiqi Luo
 */
public enum OperationType {
	get,
	put,
	delete
}
